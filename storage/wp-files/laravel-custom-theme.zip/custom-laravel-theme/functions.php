<?php
/*
* Plugin Name: Custom Plugin
* Description: This plugin is the custom plugin and created by velsof
* Version : 1.0.0
* Author: Velsof
*/
function my_cool_menu_function(){
    register_nav_menus();
}

add_action( 'after_setup_theme', 'my_cool_menu_function' );
function custom_plugin_register_settings() {

    register_setting('custom_plugin_options_group', 'instagram_url');
    register_setting('custom_plugin_options_group', 'facebook_url');
    register_setting('custom_plugin_options_group', 'youtube_url');
    register_setting('custom_plugin_options_group', 'linkedin_url');
    register_setting('custom_plugin_options_group', 'twitter_url');

}
add_action('admin_init', 'custom_plugin_register_settings');

function custom_plugin_setting_page() {

// add_options_page( string $page_title, string $menu_title, string $capability, string $menu_slug, callable $function = '' )

    add_options_page('Custom Plugin', 'Custom Plugin Setting', 'manage_options', 'custom-plugin-setting-url', 'custom_page_html_form');

// custom_page_html_form is the function in which I have written the HTML for my custom plugin form.
}
add_action('admin_menu', 'custom_plugin_setting_page');
function custom_page_html_form() { ?>
    <div class="wrap">
        <h2>Custom Plugin Setting Page Heading</h2>
        <form method="post" action="options.php">
            <?php settings_fields('custom_plugin_options_group'); ?>

            <table class="form-table">

                <tr>
                    <th><label for="first_field_id">Instagram URL:</label></th>

                    <td>
                        <input type = 'text' class="regular-text" id="first_field_id" name="instagram_url" value="<?php echo get_option('instagram_url'); ?>">
                    </td>
                </tr>

                <tr>
                    <th><label for="second_field_id">Facebook URL:</label></th>
                    <td>
                        <input type = 'text' class="regular-text" id="second_field_id" name="facebook_url" value="<?php echo get_option('facebook_url'); ?>">
                    </td>
                </tr>

                <tr>
                    <th><label for="third_field_id">YouTube URL:</label></th>
                    <td>
                        <input type = 'text' class="regular-text" id="third_field_id" name="youtube_url" value="<?php echo get_option('youtube_url'); ?>">
                    </td>
                </tr>

                <tr>
                    <th><label for="third_field_id">Twitter/X URL:</label></th>
                    <td>
                        <input type = 'text' class="regular-text" id="third_field_id" name="twitter_url" value="<?php echo get_option('twitter_url'); ?>">
                    </td>
                </tr>

                <tr>
                    <th><label for="third_field_id">LinkedIn URL:</label></th>
                    <td>
                        <input type = 'text' class="regular-text" id="third_field_id" name="linkedin_url" value="<?php echo get_option('linkedin_url'); ?>">
                    </td>
                </tr>
            </table>

            <?php submit_button(); ?>

    </div>
<?php }

function register_inquiry_order_status() {
    register_post_status( 'wc-inquiry', array(
        'label'                     => 'Enquiry',
        'public'                    => true,
        'show_in_admin_status_list' => true,
        'show_in_admin_all_list'    => true,
        'exclude_from_search'       => false,
        'label_count'               => _n_noop( 'Enquiry <span class="count">(%s)</span>', 'Enquiry <span class="count">(%s)</span>' )
    ) );
}
add_action( 'init', 'register_inquiry_order_status' );

function add_inquiry_to_order_statuses( $order_statuses ) {
    $new_order_statuses = array();
    foreach ( $order_statuses as $key => $status ) {
        $new_order_statuses[ $key ] = $status;
        if ( 'wc-processing' === $key ) {
            $new_order_statuses['wc-inquiry'] = 'Enquiry';
        }
    }
    return $new_order_statuses;
}
add_filter( 'wc_order_statuses', 'add_inquiry_to_order_statuses' );


?>

